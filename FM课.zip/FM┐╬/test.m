
long0 = 126 *pi/180;
lat0 = 45 * pi/180;
atl0 = 100;